import sqlite3

# Connect to the SQLite database
conn = sqlite3.connect('news.db')
c = conn.cursor()

# Drop the existing table if it exists
c.execute("DROP TABLE IF EXISTS news")

# Create a new table with the correct schema
c.execute('''CREATE TABLE news (
                id INTEGER PRIMARY KEY,
                title TEXT,
                content TEXT,
                image_url TEXT
            )''')

# Insert sample news data
news_data = [
    ("Arvind Kejriwal Back In Supreme Court After 18 Days And High Court Setback", "Arvind Kejriwal's challenge to his arrest was dismissed by the high court yesterday A day after the Delhi High Court dismissed his petition challenging his arrest in the liquor policy case, Chief Minister Arvind Kejriwal approached the Supreme Court today. The Aam Aadmi Party (AAP) leader's counsel raised the matter before Chief Justice of India DY Chandrachud and sought an urgent hearing. The Chief Justice refused to specify if a hearing will be granted today. We will see, we will look into it, he said.", "https://c.ndtvimg.com/2022-09/ohgva4qc_arvind-kejriwal-ani-240_120x90_09_September_22.jpg"),
    ("Results of first annual exam of 2nd PUC in Karnataka 2024", "Results of the first annual exam of 2nd PUC in Karnataka were announced on April 10 by Manjushree, Chairperson of Karnataka School Examination and Assessment Board.", "https://th-i.thgim.com/public/incoming/z0vg6t/article68049268.ece/alternates/LANDSCAPE_1200/PUC_02.jpg"),
    ("Rahul Gandhi Slams ED in Telangana Rally", 
     "Rahul Gandhi, a prominent Indian politician, criticized the Enforcement Directorate (ED) during a rally in Telangana state. He called it an 'Extortion Directorate,' suggesting tensions between the opposition party and the government.", 
     "https://c.ndtvimg.com/2024-04/al41pme8_prashant-kishor-rahul-gandhi_625x300_07_April_24.jpg"),  

    ("NIA Team Attacked in West Bengal, Mamata Questions Timing", 
     "The National Investigation Agency (NIA) faced an attack in West Bengal. Chief Minister Mamata Banerjee questioned the timing of this incident, hinting at possible political motives.", 
     "https://static.toiimg.com/thumb/msid-109083579,imgsize-754707,width-400,resizemode-4/109083579.jpg"),  

    ("Heatwave Expected to Persist in Eastern and Peninsular India", 
     "The India Meteorological Department (IMD) predicts continued heatwave conditions in eastern and peninsular regions of India. This could lead to water scarcity, health problems, and disruptions in agriculture.", 
     "https://static.toiimg.com/thumb/msid-109090730,imgsize-33162,width-400,resizemode-4/109090730.jpg"),

    ("Congress Manifesto Criticized for Irrelevant Locations", 
     "The Congress party's manifesto for the upcoming elections is facing criticism for mentioning irrelevant locations like Thailand and New York's Buffalo River. This raises questions about the seriousness and focus of their campaign promises.", 
     "https://bl-i.thgim.com/public/incoming/cneo61/article68043518.ece/alternates/FREE_1200/IMG_Congress_Release_Man_4_1_9NCKPCM2.jpg"),  

    ("Supreme Court Rules on Disclosure of Moveable Property by Candidates", 
     "India's Supreme Court has ruled that candidates in elections don't have to disclose details of every moveable property unless it significantly impacts voters' decisions. This decision might spark debate about transparency in campaign financing.", 
     "https://www.livelaw.in/h-upload/2024/04/09/750x450_532953-justice-aniruddha-bose-justice-sanjay-kumar-and-sc.webp"),

    ("Delhi CM Arvind Kejriwal's Petition Rejected by High Court", 
     "The Delhi High Court rejected a petition filed by Delhi Chief Minister Arvind Kejriwal. Details on the petition are not available, but it suggests a legal setback for the CM.", 
     "https://www.hindustantimes.com/ht-img/img/2024/04/09/550x309/arvind_kejriwal_1712657540238_1712657540419.jpg"),  

    ("Maharashtra Opposition Alliance Finalizes Seat-Sharing Agreement", 
     "Opposition parties in Maharashtra have reached an agreement on how they will distribute seats among themselves for the upcoming Lok Sabha elections. This signifies their unity and strategy against the ruling party.", 
     "https://indianexpress.com/wp-content/uploads/2024/04/SAN_6476-1.jpg"),

    ("PM Modi Addresses Rally in Uttar Pradesh", 
     "Prime Minister Narendra Modi is campaigning for the Lok Sabha elections with a rally in Uttar Pradesh, a key political battleground. Details of his speech are not provided here, but it highlights the importance of this state in the elections.", 
     "https://staticimg.amarujala.com/assets/images/2024/04/09/pm-modi-rally_614c37f8fd63082dacb4d81d650b0941.jpeg?w=674&dpr=1.0"),

    ("Normal Monsoon Expected in India, Some States May Face Deficit", 
     "While the overall monsoon season in India is expected to be normal, some states might experience rainfall deficits. This could affect agricultural production and water availability in those regions.", 
     "https://img.etimg.com/thumb/msid-109154457,width-300,height-225,imgsize-259102,resizemode-75/73-of-india-got-normal-rains-but-district-wise-data-reveals-opposite-trends-.jpg"),

    ("Woman Allegedly Paraded Half-Naked in Punjab, Investigation Launched", 
     "A disturbing report from Punjab alleges that a woman was paraded half-naked. The National Commission for Women (NCW) has expressed concern, and an investigation is underway. This highlights a serious crime against women's safety.", 
     "https://akm-img-a-in.tosshub.com/indiatoday/images/story/202404/punjab-tarn-taran-065236289-16x9_1.png?VersionId=RSYs83k5JeYbb49RsZBhQnNjpxKC3gDg&size=690:388"),  
]

c.executemany("INSERT INTO news (title, content, image_url) VALUES (?, ?, ?)", news_data)

# Commit changes and close connection
conn.commit()
conn.close()


from flask import Flask, render_template, request, jsonify
import sqlite3

app = Flask(__name__)

# Function to fetch all news articles
def fetch_all_news():
    conn = sqlite3.connect('news.db')
    c = conn.cursor()
    c.execute("SELECT * FROM news")
    news_data = c.fetchall()
    conn.close()
    return news_data

# Function to filter news articles based on search keyword
def filter_news(keyword):
    conn = sqlite3.connect('news.db')
    c = conn.cursor()
    c.execute("SELECT * FROM news WHERE title LIKE ? OR content LIKE ?", ('%'+keyword+'%', '%'+keyword+'%'))
    filtered_news = c.fetchall()
    conn.close()
    return filtered_news

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/news', methods=['GET'])
def get_news():
    news_data = fetch_all_news()
    return jsonify(news_data)

@app.route('/search', methods=['POST'])
def search_news():
    keyword = request.form['keyword'].lower()
    if keyword:
        filtered_news = filter_news(keyword)
        if filtered_news:
            return jsonify(filtered_news)
    return jsonify([])  # Return empty list if no news found

if __name__ == '__main__':
    app.run(debug=True)
